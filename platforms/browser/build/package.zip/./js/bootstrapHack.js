var jQuery = require('jquery');
window.$ = window.jQuery = jQuery;

require('bootstrap');