var questions = [
    "What's the best Taylor Swift song?",
    "What is the name of a Taylor Swift album?",
    "What genres has Taylor Swift attempted in her career?"
];


var q0Answers = [
    {
        "answer":"Love Story",
        "points": "17"
    },
    {
        "answer":"Blank Space",
        "points": "13"
    },
    {
        "answer":"You Belong With Me",
        "points": "10"
    },
    {
        "answer":"Shake It Off",
        "points": "7"
    },
    {
        "answer":"22",
        "points": "3"
    }
];

var q1Answers = [
    {
        "answer":"1989",
        "points": "20"
    },
    {
        "answer":"Red",
        "points": "10"
    },
    {
        "answer":"Fearless",
        "points": "6"
    },
    {
        "answer":"Speak Now",
        "points": "3"
    },
    {
        "answer":"Taylor Swift",
        "points": "1"
    }
];

var q2Answers = [
   {
        "answer":"Pop",
        "points": "30"
    },
    {
        "answer":"Country",
        "points": "15"
    },
    {
        "answer":"Rap",
        "points": "5"
    }
];