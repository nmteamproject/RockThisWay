var questions = [
    "What's the best Taylor Swift song?",
    "What is the name of a Taylor Swift album?",
    "What genres has Taylor Swift attempted in her career?"
];


var q0Answers = [
    {
        "answer":"Love Story",
        "points": "60"
    },
    {
        "answer":"Blank Space",
        "points": "25"
    },
    {
        "answer":"You Belong With Me",
        "points": "15"
    },
    {
        "answer":"Shake It Off",
        "points": "15"
    },
    {
        "answer":"22",
        "points": "15"
    }
];

var q1Answers = [
    {
        "answer":"1989",
        "points": "60"
    },
    {
        "answer":"Red",
        "points": "25"
    },
    {
        "answer":"Fearless",
        "points": "15"
    },
    {
        "answer":"Speak Now",
        "points": "15"
    },
    {
        "answer":"Taylor Swift",
        "points": "15"
    }
];

var q2Answers = [
   {
        "answer":"Pop",
        "points": "60"
    },
    {
        "answer":"Country",
        "points": "25"
    },
    {
        "answer":"Rap",
        "points": "15"
    }
];