var questions = [
    "Name a color on the American Flag.",
    "Name a color on the American Flag.",
    "Name a color on the American Flag.",
    "Name a color on the American Flag.",
    "Name a type of alcohol"
];


var q0Answers = [
    {
        "points": "60",
        "keywords": ["red", "crimson", "scarlet"]
    },
    {
        "points": "25",
        "keywords": ["white"]
    },
    {
        "points": "15",
        "keywords": ["blue", "dark blue"]
    }
];

var q1Answers = [
    {
        "points": "60",
        "keywords": ["red", "crimson", "scarlet"]
    },
    {
        "points": "25",
        "keywords": ["white"]
    },
    {
        "points": "15",
        "keywords": ["blue", "dark blue"]
    }
];

var q2Answers = [
    {
        "points": "60",
        "keywords": ["red", "crimson", "scarlet"]
    },
    {
        "points": "25",
        "keywords": ["white"]
    },
    {
        "points": "15",
        "keywords": ["blue", "dark blue"]
    }
];

var q3Answers = [
    {
        "points": "60",
        "keywords": ["red", "crimson", "scarlet"]
    },
    {
        "points": "25",
        "keywords": ["white"]
    },
    {
        "points": "15",
        "keywords": ["blue", "dark blue"]
    }
];


var q4Answers = [
    {
        "points": "60",
        "keywords": ["vodka", "svedka", "moonshine"]
    },
    {
        "points": "25",
        "keywords": ["whiskey"]
    },
    {
        "points": "15",
        "keywords": ["beer", "mixed drinks"]
    },
    {
        "points": "5",
        "keywords": ["rum", "white rum"]
    },
    {
        "points": "7",
        "keywords": ["tequila"]
    }
];
