var pics = [
    '<img src="images/planBeatles.png">',
    '<img src="images/planAerosmith.png">',
    '<img src="images/planTaytay.png">'
];

var planIcons = [
    '<img src="images/planIcon1.png">',
    '<img src="images/planIcon2.png">',
    '<img src="images/planIcon3.png">'
];


var exhibit0 = [
    {
        "title": "THE BEATLES EXHIBIT",
        "info1": "Learn about the legacy",
        "info2": "of The Beatles!"
    }
];

var exhibit1 = [
    {
        "title": "HISTORY OF AEROSMITH",
        "info1": "Learn about the rock icons",
        "info2": "that are Aerosmith!"
    }
];

var exhibit2 = [
    {
        "title": "TAYLOR SWIFT",
        "info1": "She's got a blank space baby,",
        "info2": "and she'll write your name."
    }
];