var songs = [
    {
        artist: "Aerosmith",
        song: "Don't Wanna Miss a Thing",
        verse: "Lieing close to you, feeling your heart beating..."
    },
    {
        artist: "Aerosmith",
        song: "Dream On",
        verse: "sing with me, sing for the year sing for the laughter, sing for the tear..."
    },
    {
        artist: "Aerosmith",
        song: "Dude (Looks Like a Lady)",
        verse: "cruise into a bar on the shore, her picture graced the grime on the door..."
    }
];

var correctLyrics = [
    "and Im wondering what youre dreaming wondering if its me youre seeing",
    "sing with me just for today maybe tomorrow the good lord will take you away",
    "shes a long lost love at first bite baby maybe youre wrong but you know its alright"
];

var lyricCollection0 = [
    "its me",
    "wondering if", 
    "what youre dreaming",
    "youre seeing",
    "and Im wondering"

];

var lyricCollection1 = [
    "maybe tomorrow",
    "just for today",
    "you away",
    "the good lord",
    "will take",
    "sing with me"
];

var lyricCollection2 = [
    
    "lost love",
    "shes a long",
    "baby maybe",
    "its alright",
    "youre wrong",
    "but you know",
    "at first bite"
    
];

var musicCollection = [
    "MissAThing",
    "DreamOn",
    "Dude"
];