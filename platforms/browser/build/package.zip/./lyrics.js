var songs = [
    {
        artist:"Don McLean",
        song:"American Pie",
        verse:"Bye Bye Mrs. American Pie..."
    },
    {
        artist:"The Beatles",
        song:"Yesterday",
        verse:"Yesterday, all my troubles seemed so far away..."
    }
]

var correctLyrics = [
    "drove my chevy to the levy but the levy was dry",
    "now it looks as though they are here to stay"
];

var lyricCollection0 = [
    "drove",
    "my",
    "chevy",
    "to",
    "the",
    "levy",
    "but",
    "the",
    "levy",
    "was",
    "dry"
];

var lyricCollection1 = [
    "now",
    "it",
    "looks",
    "as",
    "though",
    "they",
    "are",
    "here",
    "to",
    "stay"
];

var musicCollection = [
    "WorkFromHome",
    "WorkFromHome"
];